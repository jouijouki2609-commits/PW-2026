let mensagemFinal = "";
let venceu = false;
const btnRestart =
    document.getElementById(
        "btnRestart"
    );

btnRestart.addEventListener(
    "click",
    () => location.reload()
);
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const txtVidas = document.getElementById("txtVidas");
const txtMoedas = document.getElementById("txtMoedas");
const txtAbates = document.getElementById("txtAbates");
const txtOnda = document.getElementById("txtOnda");

const teclas = {};

window.addEventListener("keydown", e => teclas[e.key] = true);
window.addEventListener("keyup", e => teclas[e.key] = false);


const jogador = {
    x: 80,
    y: 500,
    raio: 15,
    velocidade: 4,
    vidas: 5,
    moedas: 0,
    abates: 0,
    ultimoDisparo: 0,
    cadencia: 180
};

const projeteis = [];
const inimigos = [];
const moedasMapa = [];

const obstaculos = [
    {x:150,y:100,largura:120,altura:60},
    {x:450,y:120,largura:70,altura:180},
    {x:260,y:400,largura:220,altura:50},
    {x:650,y:250,largura:100,altura:150}
];

let ondaAtual = 1;
let inimigosGerados = 0;
let inimigosRestantes = 10;
let jogoFinalizado = false;
let chefeCriadoNaOnda = false;

function colideRetanguloCirculo(cx,cy,raio,rx,ry,rw,rh){

    const pontoX =
        Math.max(rx, Math.min(cx, rx+rw));

    const pontoY =
        Math.max(ry, Math.min(cy, ry+rh));

    const dx = cx-pontoX;
    const dy = cy-pontoY;

    return dx*dx + dy*dy < raio*raio;
}

function gerarInimigo(){

    if(jogoFinalizado) return;
    if(inimigosGerados >= inimigosRestantes) return;

    const raio = 12;

    let x,y;

    if(Math.random() < .5){

        x = Math.random() < .5
            ? -raio
            : canvas.width + raio;

        y = Math.random()*canvas.height;

    }else{

        x = Math.random()*canvas.width;

        y = Math.random() < .5
            ? -raio
            : canvas.height + raio;
    }

    inimigos.push({

        x,
        y,

        raio,

        velocidade:
            1.5 + ondaAtual * .4,

        tipo:
            Math.random(),

        vida:1,

        chefe:false,

        direcaoX:0,
        direcaoY:0,
        trocaDirecao:0
    });

    inimigosGerados++;
}

setInterval(gerarInimigo,700);

function criarChefe(){

    inimigos.push({

        x:50,
        y:50,

        raio:30,

        velocidade:1.2,

        chefe:true,

        vida:
            20 + ondaAtual * 5,

        tipo:0,

        direcaoX:0,
        direcaoY:0,
        trocaDirecao:0
    });
}

function verificarOnda(){

    if(
        inimigosGerados >= inimigosRestantes &&
        inimigos.length === 0
    ){

        if(ondaAtual >= 5){

         jogoFinalizado = true;

        venceu = true;

        mensagemFinal = "VOCÊ VENCEU!";

            return;
        }

        ondaAtual++;

        txtOnda.innerText = ondaAtual;

        inimigosGerados = 0;
        inimigosRestantes =
            10 + ondaAtual * 8;

        chefeCriadoNaOnda = false;

        if(
            ondaAtual >= 3 &&
            !chefeCriadoNaOnda
        ){
            criarChefe();
            chefeCriadoNaOnda = true;
        }
    }
}

function gerenciarControles(){

    let novoX = jogador.x;
    let novoY = jogador.y;

    if(teclas["w"] || teclas["W"])
        novoY -= jogador.velocidade;

    if(teclas["s"] || teclas["S"])
        novoY += jogador.velocidade;

    if(teclas["a"] || teclas["A"])
        novoX -= jogador.velocidade;

    if(teclas["d"] || teclas["D"])
        novoX += jogador.velocidade;

    let colisaoX = false;
    let colisaoY = false;

    for(const obs of obstaculos){

        if(
            colideRetanguloCirculo(
                novoX,
                jogador.y,
                jogador.raio,
                obs.x,
                obs.y,
                obs.largura,
                obs.altura
            )
        ){
            colisaoX = true;
        }

        if(
            colideRetanguloCirculo(
                jogador.x,
                novoY,
                jogador.raio,
                obs.x,
                obs.y,
                obs.largura,
                obs.altura
            )
        ){
            colisaoY = true;
        }
    }

    if(!colisaoX)
        jogador.x = novoX;

    if(!colisaoY)
        jogador.y = novoY;

    jogador.x = Math.max(
        jogador.raio,
        Math.min(
            canvas.width-jogador.raio,
            jogador.x
        )
    );

    jogador.y = Math.max(
        jogador.raio,
        Math.min(
            canvas.height-jogador.raio,
            jogador.y
        )
    );

    let dx = 0;
    let dy = 0;

    if(teclas["ArrowUp"]) dy = -1;
    if(teclas["ArrowDown"]) dy = 1;
    if(teclas["ArrowLeft"]) dx = -1;
    if(teclas["ArrowRight"]) dx = 1;

    if(
        (dx !== 0 || dy !== 0) &&
        Date.now() - jogador.ultimoDisparo >
        jogador.cadencia
    ){

        const tamanho =
            Math.hypot(dx,dy);

        projeteis.push({

            x:jogador.x,
            y:jogador.y,

            velX:(dx/tamanho)*8,
            velY:(dy/tamanho)*8,

            raio:4
        });

        jogador.ultimoDisparo =
            Date.now();
    }
}

function atualizar(){

    if(jogoFinalizado) return;

    gerenciarControles();

    for(let i=projeteis.length-1;i>=0;i--){

        const p = projeteis[i];

        p.x += p.velX;
        p.y += p.velY;

        let destruir = false;

        for(const obs of obstaculos){

            if(
                colideRetanguloCirculo(
                    p.x,
                    p.y,
                    p.raio,
                    obs.x,
                    obs.y,
                    obs.largura,
                    obs.altura
                )
            ){
                destruir = true;
            }
        }

        if(
            destruir ||
            p.x<0 ||
            p.x>canvas.width ||
            p.y<0 ||
            p.y>canvas.height
        ){
            projeteis.splice(i,1);
        }
    }

    for(let i=inimigos.length-1;i>=0;i--){

        const e = inimigos[i];

        let dx = jogador.x - e.x;
        let dy = jogador.y - e.y;

        let alvoX = dx;
        let alvoY = dy;

        if(
            e.tipo > .4 &&
            e.tipo < .7 &&
            !e.chefe
        ){
            alvoX += dy*.5;
            alvoY -= dx*.5;
        }

        if(
            e.tipo >= .7 &&
            !e.chefe
        ){

            if(
                Date.now() >
                e.trocaDirecao
            ){

                e.direcaoX =
                    (Math.random()-.5)*100;

                e.direcaoY =
                    (Math.random()-.5)*100;

                e.trocaDirecao =
                    Date.now()+1000;
            }

            alvoX += e.direcaoX;
            alvoY += e.direcaoY;
        }

        let norma =
            Math.hypot(
                alvoX,
                alvoY
            );

        if(norma === 0)
            norma = 1;

        const proxX =
            e.x +
            (alvoX/norma)*
            e.velocidade;

        const proxY =
            e.y +
            (alvoY/norma)*
            e.velocidade;

        let colisao = false;

        let colisaoX = false;
let colisaoY = false;

for(const obs of obstaculos){

    if(
        colideRetanguloCirculo(
            proxX,
            e.y,
            e.raio,
            obs.x,
            obs.y,
            obs.largura,
            obs.altura
        )
    ){
        colisaoX = true;
    }

    if(
        colideRetanguloCirculo(
            e.x,
            proxY,
            e.raio,
            obs.x,
            obs.y,
            obs.largura,
            obs.altura
        )
    ){
        colisaoY = true;
    }
}

if(!colisaoX){
    e.x = proxX;
}

if(!colisaoY){
    e.y = proxY;
}
        const distancia =
            Math.hypot(
                jogador.x-e.x,
                jogador.y-e.y
            );

        if(
            distancia <
            jogador.raio + e.raio
        ){

            jogador.vidas -=
                e.chefe ? 2 : 1;

            txtVidas.innerText =
                jogador.vidas;

            inimigos.splice(i,1);

            if(jogador.vidas <= 0){

             jogoFinalizado = true;

            mensagemFinal = "GAME OVER";

            }

            continue;
        }

        for(let j=projeteis.length-1;j>=0;j--){

            const p = projeteis[j];

            const d =
                Math.hypot(
                    p.x-e.x,
                    p.y-e.y
                );

            if(
                d <
                p.raio + e.raio
            ){

                projeteis.splice(j,1);

                if(e.chefe){

                    e.vida--;

                    if(e.vida <= 0){

                        jogador.abates++;
                        jogador.moedas += 10;

                        txtMoedas.innerText =
                            jogador.moedas;

                        inimigos.splice(i,1);
                    }

                }else{

                    jogador.abates++;

                    if(Math.random()<0.4){

                        moedasMapa.push({

                            x:e.x,
                            y:e.y,
                            raio:6
                        });
                    }

                    inimigos.splice(i,1);
                }

                txtAbates.innerText =
                    jogador.abates;

                verificarOnda();

                break;
            }
        }
    }

    for(let i=moedasMapa.length-1;i>=0;i--){

        const m = moedasMapa[i];

        const d =
            Math.hypot(
                jogador.x-m.x,
                jogador.y-m.y
            );

        if(
            d <
            jogador.raio+m.raio
        ){

            jogador.moedas++;

            txtMoedas.innerText =
                jogador.moedas;

            moedasMapa.splice(i,1);
        }
    }
}

function desenhar(){

    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    obstaculos.forEach(obs=>{

        ctx.fillStyle="#6d4c41";

        ctx.fillRect(
            obs.x,
            obs.y,
            obs.largura,
            obs.altura
        );
    });

    ctx.beginPath();
    ctx.arc(
        jogador.x,
        jogador.y,
        jogador.raio,
        0,
        Math.PI*2
    );
    ctx.fillStyle="#1976d2";
    ctx.fill();

    projeteis.forEach(p=>{

        ctx.beginPath();

        ctx.arc(
            p.x,p.y,
            p.raio,
            0,
            Math.PI*2
        );

        ctx.fillStyle="gold";
        ctx.fill();
    });

    moedasMapa.forEach(m=>{

        ctx.beginPath();

        ctx.arc(
            m.x,m.y,
            m.raio,
            0,
            Math.PI*2
        );

        ctx.fillStyle="yellow";
        ctx.fill();
    });

    inimigos.forEach(e=>{

        ctx.beginPath();

        ctx.arc(
            e.x,
            e.y,
            e.raio,
            0,
            Math.PI*2
        );

        ctx.fillStyle =
            e.chefe
            ? "#c62828"
            : "#8e24aa";

        ctx.fill();

        if(e.chefe){

            ctx.fillStyle="white";
            ctx.font="12px Arial";

            ctx.fillText(
                e.vida,
                e.x-8,
                e.y+4
            );
        }
    });

    if(jogoFinalizado){

    btnRestart.style.display =
        "inline-block";

    ctx.fillStyle =
        "rgba(0,0,0,0.8)";

    ctx.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    ctx.fillStyle =
        venceu
        ? "#00ff66"
        : "#ff4444";

    ctx.font =
        "60px Arial";

    ctx.textAlign =
        "center";

    ctx.fillText(
        mensagemFinal,
        canvas.width/2,
        canvas.height/2 - 40
    );

    ctx.fillStyle =
        "white";

    ctx.font =
        "24px Arial";

    ctx.fillText(
        "Abates: " +
        jogador.abates,
        canvas.width/2,
        canvas.height/2 + 20
    );

    ctx.fillText(
        "Moedas: " +
        jogador.moedas,
        canvas.width/2,
        canvas.height/2 + 60
    );

    }
}


function gameLoop(){
    atualizar();
    desenhar();
    requestAnimationFrame(gameLoop);
}

gameLoop();