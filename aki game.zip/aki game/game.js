// Captura os elementos gráficos e de tela
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Elementos do Painel de Pontuação (DOM)
const txtVidas = document.getElementById("txtVidas");
const txtMoedas = document.getElementById("txtMoedas");
const txtAbates = document.getElementById("txtAbates");

// Dicionário para monitorar as teclas seguradas pelo jogador
const teclas = {};

// Propriedades do Jogador (Cowboy)
const jogador = {
    x: canvas.width / 2,
    y: canvas.height / 2,
    raio: 15,
    velocidade: 3,
    vidas: 3,
    moedas: 0,
    abates: 0,
    ultimoDisparo: 0,
    cadencia: 250 // Intervalo em milissegundos entre tiros
};

// Armazenamento dos arrays de entidades em movimento
const projeteis = [];
const inimigos = [];

// Ouvintes de eventos do teclado (Input)
window.addEventListener("keydown", (e) => teclas[e.key] = true);
window.addEventListener("keyup", (e) => teclas[e.key] = false);

// Função para fazer inimigos surgirem fora dos limites da tela
function gerarInimigo() {
    const raio = 12;
    let x, y;
    
    // Sorteia se nasce nas laterais (esquerda/direita) ou verticais (cima/baixo)
    if (Math.random() < 0.5) {
        x = Math.random() < 0.5 ? 0 - raio : canvas.width + raio;
        y = Math.random() * canvas.height;
    } else {
        x = Math.random() * canvas.width;
        y = Math.random() < 0.5 ? 0 - raio : canvas.height + raio;
    }
    
    inimigos.push({ x, y, raio, velocidade: 1.2 });
}

// Invocação repetida de monstros a cada 1,5 segundos
setInterval(gerarInimigo, 1500);

// Gerencia movimentação independente do ângulo de tiro (Twin-Stick)
function gerenciarControles() {
    // 1. Movimentação (WASD)
    if (teclas["w"] || teclas["W"]) jogador.y -= jogador.velocidade;
    if (teclas["s"] || teclas["S"]) jogador.y += jogador.velocidade;
    if (teclas["a"] || teclas["A"]) jogador.x -= jogador.velocidade;
    if (teclas["d"] || teclas["D"]) jogador.x += jogador.velocidade;

    // Colisão do jogador com as bordas do cenário
    jogador.x = Math.max(jogador.raio, Math.min(canvas.width - jogador.raio, jogador.x));
    jogador.y = Math.max(jogador.raio, Math.min(canvas.height - jogador.raio, jogador.y));

    // 2. Vetores de Disparo (Setas direcionais)
    let dx = 0;
    let dy = 0;
    if (teclas["ArrowUp"]) dy = -1;
    if (teclas["ArrowDown"]) dy = 1;
    if (teclas["ArrowLeft"]) dx = -1;
    if (teclas["ArrowRight"]) dx = 1;

    // Dispara caso haja direção selecionada e a cadência de tiro permita
    if ((dx !== 0 || dy !== 0) && Date.now() - jogador.ultimoDisparo > jogador.cadencia) {
        projeteis.push({
            x: jogador.x,
            y: jogador.y,
            velX: dx * 6,
            velY: dy * 6,
            raio: 4
        });
        jogador.ultimoDisparo = Date.now();
    }
}

// Lógica de cálculo matemático, coordenadas e colisões
function atualizar() {
    gerenciarControles();

    // Move e limpa projéteis fora da janela de jogo
    for (let i = projeteis.length - 1; i >= 0; i--) {
        let p = projeteis[i];
        p.x += p.velX;
        p.y += p.velY;
        
        if (p.x < 0 || p.x > canvas.width || p.y < 0 || p.y > canvas.height) {
            projeteis.splice(i, 1);
        }
    }

    // Move os inimigos em perseguição direta
    for (let i = inimigos.length - 1; i >= 0; i--) {
        let e = inimigos[i];
        
        let diffX = jogador.x - e.x;
        let diffY = jogador.y - e.y;
        let distancia = Math.sqrt(diffX * diffX + diffY * diffY);
        
        if (distancia > 0) {
            e.x += (diffX / distancia) * e.velocidade;
            e.y += (diffY / distancia) * e.velocidade;
        }

        // Detecção: Inimigo causa dano ao Jogador
        if (distancia < jogador.raio + e.raio) {
            jogador.vidas--;
            txtVidas.innerText = jogador.vidas;
            inimigos.splice(i, 1);
            
            if (jogador.vidas <= 0) {
                alert(`Game Over! Você abateu ${jogador.abates} monstros.`);
                document.location.reload();
            }
            continue;
        }

        // Detecção: Bala elimina Monstro
        for (let j = projeteis.length - 1; j >= 0; j--) {
            let p = projeteis[j];
            let distBalaInimigo = Math.sqrt((p.x - e.x)**2 + (p.y - e.y)**2);
            
            if (distBalaInimigo < p.raio + e.raio) {
                // Sorteia chance de queda de moeda (30% de chance)
                if (Math.random() < 0.3) {
                    jogador.moedas += 1;
                    txtMoedas.innerText = jogador.moedas;
                }
                
                jogador.abates++;
                txtAbates.innerText = jogador.abates;
                
                inimigos.splice(i, 1);
                projeteis.splice(j, 1);
                break;
            }
        }
    }
}

// Pintura na tela dos elementos processados
function desenhar() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Renderiza o Jogador (Círculo azul)
    ctx.beginPath();
    ctx.arc(jogador.x, jogador.y, jogador.raio, 0, Math.PI * 2);
    ctx.fillStyle = "#3498db";
    ctx.fill();
    ctx.strokeStyle = "#2980b9";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.closePath();

    // Renderiza as Balas (Círculos amarelos)
    projeteis.forEach(p => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.raio, 0, Math.PI * 2);
        ctx.fillStyle = "#f1c40f";
        ctx.fill();
        ctx.closePath();
    });

    // Renderiza Inimigos (Círculos roxos)
    inimigos.forEach(e => {
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.raio, 0, Math.PI * 2);
        ctx.fillStyle = "#9b59b6";
        ctx.fill();
        ctx.strokeStyle = "#8e44ad";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.closePath();
    });
}

// Ciclo infinito calibrado por hardware (Game Loop)
function gameLoop() {
    atualizar();
    desenhar();
    requestAnimationFrame(gameLoop);
}

// Ativação automática inicial
gameLoop();
