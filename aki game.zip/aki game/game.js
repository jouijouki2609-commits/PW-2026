// =====================================================
// O REI DA PRADARIA - SURVIVAL
// Movimento: WASD | Tiro: setas direcionais
// Objetivo: sobreviver às 5 ondas de inimigos
// =====================================================

// ---------- ESTADO FINAL DO JOGO ----------
let mensagemFinal = "";   // Texto da tela final ("VOCÊ VENCEU!" ou "GAME OVER")
let venceu = false;       // Define a cor da mensagem final (verde = vitória, vermelho = derrota)

// ---------- BOTÃO DE REINICIAR ----------
const btnRestart = document.getElementById("btnRestart");

// Reinicia o jogo recarregando a página
btnRestart.addEventListener(
    "click",
    () => location.reload()
);

// ---------- CANVAS E CONTEXTO DE DESENHO ----------
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");   // Contexto 2D usado para desenhar tudo

// ---------- ELEMENTOS DO HUD (placar da página) ----------
const txtVidas = document.getElementById("txtVidas");
const txtMoedas = document.getElementById("txtMoedas");
const txtAbates = document.getElementById("txtAbates");
const txtOnda = document.getElementById("txtOnda");

// ---------- CONTROLE DE TECLADO ----------
// Guarda quais teclas estão pressionadas (ex.: teclas["w"] = true)
const teclas = {};

window.addEventListener("keydown", e => teclas[e.key] = true);
window.addEventListener("keyup", e => teclas[e.key] = false);


// ---------- JOGADOR ----------
const jogador = {
    x: 80,               // Posição horizontal inicial
    y: 500,              // Posição vertical inicial
    raio: 15,            // Tamanho (é um círculo)
    velocidade: 4,       // Pixels por frame
    vidas: 5,
    moedas: 0,
    abates: 0,           // Inimigos eliminados
    ultimoDisparo: 0,    // Momento do último tiro (controla a cadência)
    cadencia: 180        // Intervalo mínimo entre tiros, em milissegundos
};

// ---------- LISTAS DE OBJETOS DINÂMICOS ----------
const projeteis = [];    // Tiros ativos
const inimigos = [];     // Inimigos ativos (incluindo chefes)
const moedasMapa = [];   // Moedas largadas no chão

// ---------- OBSTÁCULOS (paredes retangulares fixas) ----------
// Bloqueiam jogador, inimigos e projéteis
const obstaculos = [
    {x:150,y:100,largura:120,altura:60},
    {x:450,y:120,largura:70,altura:180},
    {x:260,y:400,largura:220,altura:50},
    {x:650,y:250,largura:100,altura:150}
];

// ---------- CONTROLE DE ONDAS ----------
let ondaAtual = 1;
let inimigosGerados = 0;        // Quantos já nasceram na onda atual
let inimigosRestantes = 10;     // Total que a onda atual vai gerar
let jogoFinalizado = false;     // Trava a lógica quando o jogo termina
let chefeCriadoNaOnda = false;  // Evita criar mais de um chefe por onda


// =====================================================
// COLISÃO: CÍRCULO x RETÂNGULO
// Acha o ponto do retângulo mais próximo do centro do círculo
// e verifica se a distância até ele é menor que o raio.
// =====================================================
function colideRetanguloCirculo(cx,cy,raio,rx,ry,rw,rh){

    // Ponto do retângulo mais próximo do centro do círculo
    // (Math.max/Math.min "prendem" o valor dentro dos limites do retângulo)
    const pontoX =
        Math.max(rx, Math.min(cx, rx+rw));

    const pontoY =
        Math.max(ry, Math.min(cy, ry+rh));

    // Distância entre o centro do círculo e esse ponto
    const dx = cx-pontoX;
    const dy = cy-pontoY;

    // Compara distância² com raio² (evita calcular raiz quadrada)
    return dx*dx + dy*dy < raio*raio;
}


// =====================================================
// GERAÇÃO DE INIMIGOS COMUNS
// Nascem fora da tela, em uma das 4 bordas, e vão atrás do jogador
// =====================================================
function gerarInimigo(){

    if(jogoFinalizado) return;                         // Não gera nada após o fim
    if(inimigosGerados >= inimigosRestantes) return;   // Já gerou todos desta onda

    const raio = 12;

    let x,y;

    // 50% de chance: nasce nas laterais (esquerda/direita)
    if(Math.random() < .5){

        x = Math.random() < .5
            ? -raio                   // Fora da tela, à esquerda
            : canvas.width + raio;    // Fora da tela, à direita

        y = Math.random()*canvas.height;

    // Nos outros 50%: nasce em cima ou embaixo
    }else{

        x = Math.random()*canvas.width;

        y = Math.random() < .5
            ? -raio                    // Fora da tela, acima
            : canvas.height + raio;    // Fora da tela, abaixo
    }

    inimigos.push({

        x,
        y,

        raio,

        // A velocidade aumenta a cada onda
        velocidade:
            1.5 + ondaAtual * .4,

        // Número aleatório que define o comportamento do inimigo:
        //   < 0.4       -> persegue em linha reta
        //   0.4 a 0.7   -> persegue em curva (espiral)
        //   >= 0.7      -> persegue de forma errática (zigue-zague)
        tipo:
            Math.random(),

        vida:1,

        chefe:false,

        // Usados apenas pelo tipo errático
        direcaoX:0,
        direcaoY:0,
        trocaDirecao:0   // Momento da próxima mudança de direção
    });

    inimigosGerados++;
}

// Tenta gerar um inimigo a cada 700 ms (o limite por onda é controlado dentro da função)
setInterval(gerarInimigo,700);


// =====================================================
// CRIAÇÃO DO CHEFE
// Nasce no canto superior esquerdo, é maior e tem mais vida
// =====================================================
function criarChefe(){

    inimigos.push({

        x:50,
        y:50,

        raio:30,

        velocidade:1.2,   // Mais lento que os inimigos comuns

        chefe:true,

        // A vida do chefe cresce com a onda
        vida:
            20 + ondaAtual * 5,

        tipo:0,           // Sempre persegue em linha reta

        direcaoX:0,
        direcaoY:0,
        trocaDirecao:0
    });
}


// =====================================================
// VERIFICAÇÃO DE ONDA
// Quando todos os inimigos da onda foram gerados E eliminados,
// avança para a próxima onda (ou vence o jogo na onda 5).
// =====================================================
function verificarOnda(){

    if(
        inimigosGerados >= inimigosRestantes &&
        inimigos.length === 0
    ){

        // Concluiu a última onda: vitória
        if(ondaAtual >= 5){

            jogoFinalizado = true;

            venceu = true;

            mensagemFinal = "VOCÊ VENCEU!";

            return;
        }

        // Avança para a próxima onda
        ondaAtual++;

        txtOnda.innerText = ondaAtual;

        // Reseta o contador e aumenta a quantidade de inimigos
        inimigosGerados = 0;
        inimigosRestantes =
            10 + ondaAtual * 8;

        chefeCriadoNaOnda = false;

        // A partir da onda 3, cada onda começa com um chefe
        if(
            ondaAtual >= 3 &&
            !chefeCriadoNaOnda
        ){
            criarChefe();
            chefeCriadoNaOnda = true;
        }
    }
}


// =====================================================
// CONTROLES DO JOGADOR (movimento + tiro)
// =====================================================
function gerenciarControles(){

    // Posição desejada após o movimento (ainda não aplicada)
    let novoX = jogador.x;
    let novoY = jogador.y;

    // ----- Movimento com WASD (aceita maiúsculas por causa do Caps Lock) -----
    if(teclas["w"] || teclas["W"])
        novoY -= jogador.velocidade;

    if(teclas["s"] || teclas["S"])
        novoY += jogador.velocidade;

    if(teclas["a"] || teclas["A"])
        novoX -= jogador.velocidade;

    if(teclas["d"] || teclas["D"])
        novoX += jogador.velocidade;

    // ----- Colisão com obstáculos, testando cada eixo separadamente -----
    // Isso permite "deslizar" pela parede em vez de travar ao encostar nela
    let colisaoX = false;
    let colisaoY = false;

    for(const obs of obstaculos){

        // Testa só o movimento horizontal
        if(
            colideRetanguloCirculo(
                novoX,
                jogador.y,
                jogador.raio,
                obs.x,
                obs.y,
                obs.largura,
                obs.altura
            )
        ){
            colisaoX = true;
        }

        // Testa só o movimento vertical
        if(
            colideRetanguloCirculo(
                jogador.x,
                novoY,
                jogador.raio,
                obs.x,
                obs.y,
                obs.largura,
                obs.altura
            )
        ){
            colisaoY = true;
        }
    }

    // Só aplica o movimento nos eixos livres
    if(!colisaoX)
        jogador.x = novoX;

    if(!colisaoY)
        jogador.y = novoY;

    // ----- Mantém o jogador dentro dos limites do canvas -----
    jogador.x = Math.max(
        jogador.raio,
        Math.min(
            canvas.width-jogador.raio,
            jogador.x
        )
    );

    jogador.y = Math.max(
        jogador.raio,
        Math.min(
            canvas.height-jogador.raio,
            jogador.y
        )
    );

    // ----- Direção do tiro com as setas -----
    let dx = 0;
    let dy = 0;

    if(teclas["ArrowUp"]) dy = -1;
    if(teclas["ArrowDown"]) dy = 1;
    if(teclas["ArrowLeft"]) dx = -1;
    if(teclas["ArrowRight"]) dx = 1;

    // Atira se alguma seta está pressionada E o tempo de recarga já passou
    if(
        (dx !== 0 || dy !== 0) &&
        Date.now() - jogador.ultimoDisparo >
        jogador.cadencia
    ){

        // Normaliza o vetor para que tiros na diagonal não sejam mais rápidos
        const tamanho =
            Math.hypot(dx,dy);

        projeteis.push({

            x:jogador.x,
            y:jogador.y,

            // Velocidade do projétil: 8 px/frame na direção escolhida
            velX:(dx/tamanho)*8,
            velY:(dy/tamanho)*8,

            raio:4
        });

        jogador.ultimoDisparo =
            Date.now();
    }
}


// =====================================================
// ATUALIZAÇÃO DA LÓGICA (executada a cada frame)
// =====================================================
function atualizar(){

    if(jogoFinalizado) return;   // Congela o jogo após o fim

    gerenciarControles();

    // ---------------- PROJÉTEIS ----------------
    // Percorre de trás para frente para remover itens com splice com segurança
    for(let i=projeteis.length-1;i>=0;i--){

        const p = projeteis[i];

        // Move o projétil
        p.x += p.velX;
        p.y += p.velY;

        let destruir = false;

        // Destrói o projétil se bater em um obstáculo
        for(const obs of obstaculos){

            if(
                colideRetanguloCirculo(
                    p.x,
                    p.y,
                    p.raio,
                    obs.x,
                    obs.y,
                    obs.largura,
                    obs.altura
                )
            ){
                destruir = true;
            }
        }

        // Destrói também se sair da tela
        if(
            destruir ||
            p.x<0 ||
            p.x>canvas.width ||
            p.y<0 ||
            p.y>canvas.height
        ){
            projeteis.splice(i,1);
        }
    }

    // ---------------- INIMIGOS ----------------
    for(let i=inimigos.length-1;i>=0;i--){

        const e = inimigos[i];

        // Vetor apontando do inimigo até o jogador
        let dx = jogador.x - e.x;
        let dy = jogador.y - e.y;

        // Alvo do movimento (começa igual ao vetor até o jogador)
        let alvoX = dx;
        let alvoY = dy;

        // TIPO CURVO: soma um vetor perpendicular, fazendo o inimigo
        // se aproximar em curva/espiral
        if(
            e.tipo > .4 &&
            e.tipo < .7 &&
            !e.chefe
        ){
            alvoX += dy*.5;
            alvoY -= dx*.5;
        }

        // TIPO ERRÁTICO: a cada 1 segundo sorteia um desvio aleatório
        // que é somado à direção do jogador
        if(
            e.tipo >= .7 &&
            !e.chefe
        ){

            if(
                Date.now() >
                e.trocaDirecao
            ){

                e.direcaoX =
                    (Math.random()-.5)*100;

                e.direcaoY =
                    (Math.random()-.5)*100;

                e.trocaDirecao =
                    Date.now()+1000;
            }

            alvoX += e.direcaoX;
            alvoY += e.direcaoY;
        }

        // Normaliza o vetor para que o inimigo ande sempre na mesma velocidade
        let norma =
            Math.hypot(
                alvoX,
                alvoY
            );

        if(norma === 0)
            norma = 1;   // Evita divisão por zero

        // Próxima posição desejada do inimigo
        const proxX =
            e.x +
            (alvoX/norma)*
            e.velocidade;

        const proxY =
            e.y +
            (alvoY/norma)*
            e.velocidade;

        let colisao = false;   // (variável não utilizada, mantida do código original)

        // Colisão com obstáculos, separada por eixo (mesma técnica do jogador)
        let colisaoX = false;
        let colisaoY = false;

        for(const obs of obstaculos){

            if(
                colideRetanguloCirculo(
                    proxX,
                    e.y,
                    e.raio,
                    obs.x,
                    obs.y,
                    obs.largura,
                    obs.altura
                )
            ){
                colisaoX = true;
            }

            if(
                colideRetanguloCirculo(
                    e.x,
                    proxY,
                    e.raio,
                    obs.x,
                    obs.y,
                    obs.largura,
                    obs.altura
                )
            ){
                colisaoY = true;
            }
        }

        // Move apenas nos eixos livres
        if(!colisaoX){
            e.x = proxX;
        }

        if(!colisaoY){
            e.y = proxY;
        }

        // ----- Colisão inimigo x jogador -----
        const distancia =
            Math.hypot(
                jogador.x-e.x,
                jogador.y-e.y
            );

        if(
            distancia <
            jogador.raio + e.raio
        ){

            // Chefe tira 5 vidas, inimigo comum tira 1
            jogador.vidas -=
                e.chefe ? 5 : 1;

            txtVidas.innerText =
                jogador.vidas;

            // O inimigo some ao atingir o jogador
            inimigos.splice(i,1);

            // Fim de jogo se as vidas acabarem
            if(jogador.vidas <= 0){

                jogoFinalizado = true;

                mensagemFinal = "GAME OVER";

            }else{

                // CORREÇÃO DA NOVA ONDA:
                // o inimigo removido pode ter sido o último da onda.
                // Antes, a onda só era verificada quando um tiro matava o inimigo,
                // então morrer encostando no jogador deixava o jogo "travado"
                // sem inimigos e sem avançar de onda.
                verificarOnda();
            }

            continue;   // Vai para o próximo inimigo
        }

        // ----- Colisão inimigo x projéteis -----
        for(let j=projeteis.length-1;j>=0;j--){

            const p = projeteis[j];

            const d =
                Math.hypot(
                    p.x-e.x,
                    p.y-e.y
                );

            if(
                d <
                p.raio + e.raio
            ){

                // O projétil é consumido ao acertar
                projeteis.splice(j,1);

                if(e.chefe){

                    // Chefe perde 1 de vida por tiro
                    e.vida--;

                    // Chefe morreu: dá 10 moedas direto ao jogador
                    if(e.vida <= 0){

                        jogador.abates++;
                        jogador.moedas += 10;

                        txtMoedas.innerText =
                            jogador.moedas;

                        inimigos.splice(i,1);
                    }

                }else{

                    // Inimigo comum morre com 1 tiro
                    jogador.abates++;

                    // 40% de chance de largar uma moeda no chão
                    if(Math.random()<0.4){

                        moedasMapa.push({

                            x:e.x,
                            y:e.y,
                            raio:6
                        });
                    }

                    inimigos.splice(i,1);
                }

                txtAbates.innerText =
                    jogador.abates;

                // Checa se a onda terminou
                verificarOnda();

                break;   // Este inimigo já foi tratado; sai do loop de projéteis
            }
        }
    }

    // ---------------- MOEDAS NO CHÃO ----------------
    for(let i=moedasMapa.length-1;i>=0;i--){

        const m = moedasMapa[i];

        const d =
            Math.hypot(
                jogador.x-m.x,
                jogador.y-m.y
            );

        // Jogador encostou na moeda: coleta
        if(
            d <
            jogador.raio+m.raio
        ){

            jogador.moedas++;

            txtMoedas.innerText =
                jogador.moedas;

            moedasMapa.splice(i,1);
        }
    }
}


// =====================================================
// DESENHO (executado a cada frame)
// =====================================================
function desenhar(){

    // Limpa o frame anterior
    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    // ----- Obstáculos (marrons) -----
    obstaculos.forEach(obs=>{

        ctx.fillStyle="#6d4c41";

        ctx.fillRect(
            obs.x,
            obs.y,
            obs.largura,
            obs.altura
        );
    });

    // ----- Jogador (círculo azul) -----
    ctx.beginPath();
    ctx.arc(
        jogador.x,
        jogador.y,
        jogador.raio,
        0,
        Math.PI*2
    );
    ctx.fillStyle="#1976d2";
    ctx.fill();

    // ----- Projéteis (dourados) -----
    projeteis.forEach(p=>{

        ctx.beginPath();

        ctx.arc(
            p.x,p.y,
            p.raio,
            0,
            Math.PI*2
        );

        ctx.fillStyle="gold";
        ctx.fill();
    });

    // ----- Moedas no chão (amarelas) -----
    moedasMapa.forEach(m=>{

        ctx.beginPath();

        ctx.arc(
            m.x,m.y,
            m.raio,
            0,
            Math.PI*2
        );

        ctx.fillStyle="yellow";
        ctx.fill();
    });

    // ----- Inimigos -----
    inimigos.forEach(e=>{

        ctx.beginPath();

        ctx.arc(
            e.x,
            e.y,
            e.raio,
            0,
            Math.PI*2
        );

        // Chefe é vermelho, inimigos comuns são roxos
        ctx.fillStyle =
            e.chefe
            ? "#c62828"
            : "#8e24aa";

        ctx.fill();

        // Mostra a vida restante do chefe dentro dele
        if(e.chefe){

            ctx.fillStyle="white";
            ctx.font="12px Arial";

            ctx.fillText(
                e.vida,
                e.x-8,
                e.y+4
            );
        }
    });

    // ----- Tela de fim de jogo -----
    if(jogoFinalizado){

        // Mostra o botão de reiniciar
        btnRestart.style.display =
            "inline-block";

        // Película escura sobre o jogo
        ctx.fillStyle =
            "rgba(0,0,0,0.8)";

        ctx.fillRect(
            0,
            0,
            canvas.width,
            canvas.height
        );

        // Mensagem principal: verde se venceu, vermelha se perdeu
        ctx.fillStyle =
            venceu
            ? "#00ff66"
            : "#ff4444";

        ctx.font =
            "60px Arial";

        ctx.textAlign =
            "center";

        ctx.fillText(
            mensagemFinal,
            canvas.width/2,
            canvas.height/2 - 40
        );

        // Estatísticas finais
        ctx.fillStyle =
            "white";

        ctx.font =
            "24px Arial";

        ctx.fillText(
            "Abates: " +
            jogador.abates,
            canvas.width/2,
            canvas.height/2 + 20
        );

        ctx.fillText(
            "Moedas: " +
            jogador.moedas,
            canvas.width/2,
            canvas.height/2 + 60
        );

    }
}


// =====================================================
// LOOP PRINCIPAL
// Atualiza a lógica, desenha e agenda o próximo frame (~60 FPS)
// =====================================================
function gameLoop(){
    atualizar();
    desenhar();
    requestAnimationFrame(gameLoop);
}

gameLoop();   // Inicia o jogo