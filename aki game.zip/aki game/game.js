
// Declara o estado que indica se a partida começou.
let jogoIniciado = false;
// Declara o estado que indica se a partida está pausada.
let jogoPausado = false;
// Declara o estado que indica se os créditos estão abertos.
let jogoCreditos = false;
    
// Declara o menu inicial da partida.
const menuInicial = document.getElementById("menuInicial");
//declara o botão que inicia a partida.
const btnStart = document.getElementById("btnStart");
// Declara o menu de pausa.
const menuPause = document.getElementById("menuPause");
// Declara o botão que retoma a partida.
const btnContinue = document.getElementById("btnContinue");
// Declara o botão que abre os créditos.
const btnCreditos = document.getElementById("btnCreditos");

// Registra a ação executada no evento indicado.
btnStart.addEventListener("click", () => {
    // Atualiza o estado que indica se a partida começou.
    jogoIniciado = true;
    // Atualiza a aparência do elemento na página.
    menuInicial.style.display = "none";
});
// Registra uma ação para pressionar uma tecla.
window.addEventListener("keydown", e => {
    // Verifica se a condição permite executar o bloco seguinte.
    if (e.code === "Space" && jogoIniciado == false) {
        // Impede o comportamento padrão do navegador.
        e.preventDefault();
        btnStart.click();
    }
});
// Registra a ação executada no evento indicado.
btnContinue.addEventListener("click", () => {
    // Atualiza o estado que indica se a partida está pausada.
    jogoPausado = false;
    // Atualiza a aparência do elemento na página.
    menuPause.style.display = "none";
    // Percorre os itens ou repete as instruções do laço.
    Object.keys(teclas).forEach(tecla => teclas[tecla] = false);
});
// Registra uma ação para pressionar uma tecla.
window.addEventListener("keydown", e => {
    // Verifica se a condição permite executar o bloco seguinte.
    if (e.code === "Space" && jogoPausado && jogoCreditos == false) {
        // Impede o comportamento padrão do navegador.
        e.preventDefault();
        btnContinue.click();
    }
});
// Registra a ação executada no evento indicado.
btnCreditos.addEventListener("click", () => {
  // Atualiza o estado que indica se os créditos estão abertos.
  jogoCreditos = true;
  // Atualiza a aparência do elemento na página.
  menuCreditos.style.display = "flex";
});
// Registra a ação executada no evento indicado.
btnFecharCreditos.addEventListener("click", () => {
    // Atualiza o estado que indica se os créditos estão abertos.
    jogoCreditos = false;
    // Atualiza a aparência do elemento na página.
    menuCreditos.style.display = "none";
});
// Registra uma ação para pressionar uma tecla.
window.addEventListener("keydown", e => {
    // Verifica se a condição permite executar o bloco seguinte.
    if (e.code === "Space" && jogoCreditos === true) {
        // Impede o comportamento padrão do navegador.
        e.preventDefault();
        btnFecharCreditos.click();
    }
});

// Declara o texto exibido ao terminar a partida.
let mensagemFinal = "";
// Declara o estado que indica se o jogador venceu.
let venceu = false;

// Declara o botão que reinicia a partida.
const btnRestart = document.getElementById("btnRestart");

// Registra a ação executada no evento indicado.
btnRestart.addEventListener(
    "click",
    () => location.reload()
     );
// Registra uma ação para pressionar uma tecla.
window.addEventListener("keydown", e => {
    // Verifica se a condição permite executar o bloco seguinte.
    if (e.code === "Space" && jogoFinalizado) {
        // Impede o comportamento padrão do navegador.
        e.preventDefault();
        btnRestart.click();
    }
});
// Declara a área de desenho do jogo.
const canvas = document.getElementById("gameCanvas");
// Declara o contexto usado para desenhar no canvas.
const ctx = canvas.getContext("2d");

// Declara o elemento que mostra as vidas.
const txtVidas = document.getElementById("txtVidas");
// Declara o elemento que mostra as moedas.
const txtMoedas = document.getElementById("txtMoedas");
// Declara o elemento que mostra os abates.
const txtAbates = document.getElementById("txtAbates");
// Declara o elemento que mostra a onda atual.
const txtOnda = document.getElementById("txtOnda");

// Declara o registro das teclas pressionadas.
const teclas = {};

// Registra uma ação para pressionar uma tecla.
window.addEventListener("keydown", e => {
    // Atualiza o estado da tecla pressionada ou solta.
    teclas[e.key] = true;
     // Verifica se a condição permite executar o bloco seguinte.
     if (e.key === "ArrowUp" || e.key === "ArrowDown") {
        // Impede o comportamento padrão do navegador.
        e.preventDefault();
    }
    // Verifica se a condição permite executar o bloco seguinte.
    if (
        // Atualiza o valor de e.code.
        e.code === "Escape" &&
        jogoIniciado &&
        // Compara os valores para determinar o resultado da condição.
        !jogoFinalizado && jogoCreditos == false &&
        !e.repeat
    ) {
        // Impede o comportamento padrão do navegador.
        e.preventDefault();
        // Atualiza o estado que indica se a partida está pausada.
        jogoPausado = !jogoPausado;
        // Atualiza a aparência do elemento na página.
        menuPause.style.display = jogoPausado ? "flex" : "none";
        // Percorre os itens ou repete as instruções do laço.
        Object.keys(teclas).forEach(tecla => teclas[tecla] = false);
    }
});
// Registra uma ação para soltar uma tecla.
window.addEventListener("keyup", e => teclas[e.key] = false);


// Declara os dados e o estado do jogador.
const jogador = {
    // Define o valor da propriedade x.
    x: 80,
    // Define o valor da propriedade y.
    y: 500,
    // Define o raio do objeto circular.
    raio: 15,
    // Define o valor da propriedade velocidade.
    velocidade: 4,
    // Define o valor da propriedade vidas.
    vidas: 5,
    // Limita a quantidade máxima de vidas recuperáveis.
    vidasMaximas: 5,
    // Define o valor da propriedade moedas.
    moedas: 0,
    // Define o valor da propriedade abates.
    abates: 0,
    // Define o valor da propriedade ultimoDisparo.
    ultimoDisparo: 0,
    // Define o valor da propriedade cadencia.
    cadencia: 180
};

// Guarda os itens, preços, plataformas e efeitos disponíveis na loja.
const itensLoja = [
    {
        // Nome exibido quando o jogador toca no item.
        nome: "Cura (+1 vida)",
        // Ícone mostrado sobre a plataforma.
        icone: "💊",
        // Custo da cura em moedas.
        preco: 8,
        // Define a posição e o tamanho da plataforma da cura.
        plataforma: { x: 230, y: 320, largura: 130, altura: 75 },
        // Impede a compra quando o jogador já tem todas as vidas.
        limiteAtingido: () => jogador.vidas >= jogador.vidasMaximas,
        // Recupera uma vida e atualiza o placar.
        aplicar: () => {
            jogador.vidas++;
            txtVidas.innerText = jogador.vidas;
        }
    },
    {
        // Nome exibido quando o jogador toca no item.
        nome: "Velocidade (+0,5)",
        // Ícone mostrado sobre a plataforma.
        icone: "👟",
        // Custo do aumento de velocidade em moedas.
        preco: 12,
        // Define a posição e o tamanho da plataforma de velocidade.
        plataforma: { x: 375, y: 320, largura: 130, altura: 75 },
        // Limita a velocidade máxima do jogador.
        limiteAtingido: () => jogador.velocidade >= 6,
        // Aumenta a velocidade sem ultrapassar o limite.
        aplicar: () => {
            jogador.velocidade = Math.min(6, jogador.velocidade + 0.5);
        }
    },
    {
        // Nome exibido quando o jogador toca no item.
        nome: "Disparo mais rápido",
        // Ícone mostrado sobre a plataforma.
        icone: "🔫",
        // Custo da melhoria de disparo em moedas.
        preco: 15,
        // Define a posição e o tamanho da plataforma de disparo.
        plataforma: { x: 520, y: 320, largura: 130, altura: 75 },
        // Impede reduzir a cadência abaixo do limite definido.
        limiteAtingido: () => jogador.cadencia <= 80,
        // Reduz o intervalo entre disparos sem ultrapassar o limite.
        aplicar: () => {
            jogador.cadencia = Math.max(80, jogador.cadencia - 25);
        }
    }
];

// Define a área onde o jogador precisa permanecer para iniciar a próxima onda.
const zonaIniciarOnda = { x: 790, y: 500, raio: 55 };
// Define quantos segundos o jogador precisa ficar na zona.
const tempoParaIniciarOnda = 3;
// Indica se o jogo está combatendo ou na loja.
let faseJogo = "jogando";
// Guarda o tempo acumulado na zona de início da onda.
let progressoZona = 0;
// Guarda mensagens temporárias exibidas durante as compras.
let mensagemLoja = "";

// Declara a lista de projéteis ativos.
const projeteis = [];
// Declara a lista de inimigos ativos.
const inimigos = [];
// Declara a lista de moedas no cenário.
const moedasMapa = [];

// Declara a lista de obstáculos do cenário.
const obstaculos = [
    {x:150,y:100,largura:120,altura:60},
    {x:450,y:120,largura:70,altura:180},
    {x:260,y:400,largura:220,altura:50},
    {x:650,y:250,largura:100,altura:150}
// Encerra a lista.
];

// Declara o número da onda atual.
let ondaAtual = 1;
// Declara a quantidade de inimigos já criados na onda.
let inimigosGerados = 0;
// Declara a quantidade de inimigos previstos para a onda.
let inimigosRestantes = 15;
// Declara o estado que bloqueia a partida após seu fim.
let jogoFinalizado = false;
// Declara o estado que evita criar mais de um chefe na onda.
let chefeCriadoNaOnda = false;



// Verifica se um círculo toca um retângulo.
function colideRetanguloCirculo(cx,cy,raio,rx,ry,rw,rh){

    // Declara a coordenada horizontal do ponto mais próximo.
    const pontoX =
        // Limita o valor ao intervalo permitido.
        Math.max(rx, Math.min(cx, rx+rw));

    // Declara a coordenada vertical do ponto mais próximo.
    const pontoY =
        // Limita o valor ao intervalo permitido.
        Math.max(ry, Math.min(cy, ry+rh));

    // Declara a diferença horizontal usada no cálculo.
    const dx = cx-pontoX;
    // Declara a diferença vertical usada no cálculo.
    const dy = cy-pontoY;

    // Encerra a função e devolve o resultado indicado.
    return dx*dx + dy*dy < raio*raio;
}

// Verifica se o jogador encostou no ícone do item indicado.
function jogadorTocandoItem(indice) {
    // Recupera a plataforma que posiciona o ícone do item.
    const item = itensLoja[indice];
    if (!item) return false;

    // Calcula o centro aproximado do ícone desenhado acima da plataforma.
    const centroX = item.plataforma.x + item.plataforma.largura / 2;
    const centroY = item.plataforma.y - 23;
    // Usa a distância entre círculos para detectar o toque no ícone.
    return Math.hypot(jogador.x - centroX, jogador.y - centroY) <= jogador.raio + 14;
}

// Compra o item indicado se o jogador tocar seu ícone e puder pagar.
function comprarItem(indice) {
    // Bloqueia compras fora da pausa entre ondas.
    if (faseJogo !== "loja") return;
    // Exige contato com o item antes de tentar a compra.
    if (!jogadorTocandoItem(indice)) {
        mensagemLoja = "Encoste no item para comprar.";
        return;
    }

    // Recupera os dados do item solicitado.
    const item = itensLoja[indice];
    // Ignora índices que não correspondem a um item.
    if (!item) return;

    // Evita comprar melhorias que já chegaram ao limite.
    if (item.limiteAtingido()) {
        mensagemLoja = "Esse item já está no nível máximo.";
        return;
    }

    // Não permite gastar mais moedas do que o jogador possui.
    if (jogador.moedas < item.preco) {
        mensagemLoja = "Moedas insuficientes.";
        return;
    }

    // Cobra o preço, atualiza o placar e aplica o efeito do item.
    jogador.moedas -= item.preco;
    txtMoedas.innerText = jogador.moedas;
    item.aplicar();
    mensagemLoja = "Item comprado!";
}

// Usa E para comprar o item cujo ícone está sendo tocado.
window.addEventListener("keydown", e => {
    // Aceita E uma única vez e apenas durante a fase da loja.
    if (faseJogo !== "loja" || e.repeat || e.key.toLowerCase() !== "e") return;

    e.preventDefault();
    // Descobre qual ícone está em contato com o jogador.
    const indice = itensLoja.findIndex((_, index) =>
        jogadorTocandoItem(index)
    );

    // Informa que é preciso tocar um ícone antes de comprar.
    if (indice === -1) {
        mensagemLoja = "Encoste no ícone do item desejado.";
        return;
    }

    // Compra o item que está sendo tocado.
    comprarItem(indice);
});



// Cria e posiciona um inimigo comum.
function gerarInimigo(){

    // Gera inimigos somente durante o combate ativo.
    if(!jogoIniciado || jogoPausado || jogoFinalizado || faseJogo !== "jogando") return;
    // Verifica se a condição permite executar o bloco seguinte.
    if(inimigosGerados >= inimigosRestantes) return;

    // Declara o raio do objeto circular.
    const raio = 12;

    // Declara a variável x usada pelo jogo.
    let x,y;

    // Verifica se a condição permite executar o bloco seguinte.
    if(Math.random() < .5){

        // Gera um valor aleatório para decidir esta ação.
        x = Math.random() < .5
            // Escolhe o valor correspondente ao resultado da condição.
            ? -raio
            // Escolhe o valor correspondente ao resultado da condição.
            : canvas.width + raio;

        // Gera um valor aleatório para decidir esta ação.
        y = Math.random()*canvas.height;
    }else{

        // Gera um valor aleatório para decidir esta ação.
        x = Math.random()*canvas.width;

        // Gera um valor aleatório para decidir esta ação.
        y = Math.random() < .5
            // Escolhe o valor correspondente ao resultado da condição.
            ? -raio
            // Escolhe o valor correspondente ao resultado da condição.
            : canvas.height + raio;
    }

    // Adiciona um novo item à lista.
    inimigos.push({
        x,
        y,
        raio,

        // Define o valor da propriedade velocidade.
        velocidade:
            1.5 + ondaAtual * .4,

        // Define o valor da propriedade tipo.
        tipo:
            // Gera um valor aleatório para decidir esta ação.
            Math.random(),

        // Define o valor da propriedade vida.
        vida:1,

        // Define o valor da propriedade chefe.
        chefe:false,

        // Define o valor da propriedade direcaoX.
        direcaoX:0,
        // Define o valor da propriedade direcaoY.
        direcaoY:0,
        // Define o valor da propriedade trocaDirecao.
        trocaDirecao:0
    });

    // Incrementa ou decrementa o contador inimigosGerados.
    inimigosGerados++;
}

// Agenda a execução repetida da função indicada.
setInterval(gerarInimigo,700);



// Cria o chefe da onda atual.
function criarChefe(){

    // Adiciona um novo item à lista.
    inimigos.push({

        // Define o valor da propriedade x.
        x:50,
        // Define o valor da propriedade y.
        y:50,

        // Define o raio do objeto circular.
        raio:30,

        // Define o valor da propriedade velocidade.
        velocidade:1.2,

        // Define o valor da propriedade chefe.
        chefe:true,

        // Define o valor da propriedade vida.
        vida:
            20 + ondaAtual * 5,

        // Define o valor da propriedade tipo.
        tipo:0,

        // Define o valor da propriedade direcaoX.
        direcaoX:0,
        // Define o valor da propriedade direcaoY.
        direcaoY:0,
        // Define o valor da propriedade trocaDirecao.
        trocaDirecao:0
    });
}




// Confere se a onda terminou e prepara a próxima.
function verificarOnda(){
    // Evita processar novamente a onda durante a loja.
    if (faseJogo !== "jogando") return;

    // Abre a loja quando todos os inimigos da onda foram eliminados.
    if(
        inimigosGerados >= inimigosRestantes &&
        // Atualiza o valor de inimigos.length.
        inimigos.length === 0
    ){

        // Encerra o jogo com vitória após a última onda.
        if(ondaAtual >= 5){

            // Atualiza o estado que bloqueia a partida após seu fim.
            jogoFinalizado = true;

            // Atualiza o estado que indica se o jogador venceu.
            venceu = true;

            // Atualiza o texto exibido ao terminar a partida.
            mensagemFinal = "VOCÊ VENCEU!";

            // Encerra a função e devolve o resultado indicado.
            return;
        }

        // Mantém a fase de combate ativa enquanto houver moedas no mapa.
        if (moedasMapa.length > 0) return;

        // Pausa o combate e inicia a fase de compras.
        faseJogo = "loja";
        progressoZona = 0;
        projeteis.length = 0;
        mensagemLoja = "Compre itens e depois vá à zona de início.";
    }
}

// Avança os contadores e prepara os inimigos da próxima onda.
function iniciarProximaOnda() {
    // Atualiza a onda e a quantidade de inimigos que serão gerados.
    ondaAtual++;
    txtOnda.innerText = ondaAtual;
    inimigosGerados = 0;
    inimigosRestantes = 15 * ondaAtual;
    chefeCriadoNaOnda = false;
    // Retoma o combate e limpa o estado da loja.
    faseJogo = "jogando";
    progressoZona = 0;
    mensagemLoja = "";

    // Cria um chefe a partir da terceira onda.
    if (ondaAtual >= 3 && !chefeCriadoNaOnda) {
        criarChefe();
        chefeCriadoNaOnda = true;
    }

    // Evita esperar pelo próximo ciclo do temporizador para iniciar o combate.
    gerarInimigo();
}

// Acumula tempo na zona e inicia a onda quando o jogador permanece nela.
function atualizarProgressoZona(deltaTempo) {
    // Mede a distância do jogador até o centro da zona.
    const distancia = Math.hypot(
        jogador.x - zonaIniciarOnda.x,
        jogador.y - zonaIniciarOnda.y
    );

    // Mantém o progresso enquanto o jogador estiver dentro da zona.
    if (distancia <= zonaIniciarOnda.raio) {
        progressoZona += deltaTempo;
        // Começa a próxima onda após completar o tempo de espera.
        if (progressoZona >= tempoParaIniciarOnda) {
            iniciarProximaOnda();
        }
    } else {
        // Reinicia a contagem se o jogador sair da zona.
        progressoZona = 0;
    }
}


// Processa o movimento e os disparos do jogador.
function gerenciarControles(){

    // Declara a posição horizontal desejada para o jogador.
    let novoX = jogador.x;
    // Declara a posição vertical desejada para o jogador.
    let novoY = jogador.y;

    // Verifica se a condição permite executar o bloco seguinte.
    if(teclas["w"] || teclas["W"])
        // Atualiza a posição vertical desejada para o jogador.
        novoY -= jogador.velocidade;

    // Verifica se a condição permite executar o bloco seguinte.
    if(teclas["s"] || teclas["S"])
        // Atualiza a posição vertical desejada para o jogador.
        novoY += jogador.velocidade;

    // Verifica se a condição permite executar o bloco seguinte.
    if(teclas["a"] || teclas["A"])
        // Atualiza a posição horizontal desejada para o jogador.
        novoX -= jogador.velocidade;

    // Verifica se a condição permite executar o bloco seguinte.
    if(teclas["d"] || teclas["D"])
        // Atualiza a posição horizontal desejada para o jogador.
        novoX += jogador.velocidade;

  // Verifica se a condição permite executar o bloco seguinte.
  if (teclas["r"] || teclas["R"]) {
    // Atualiza o estado que bloqueia a partida após seu fim.
    jogoFinalizado = true;
    // Atualiza o texto exibido ao terminar a partida.
    mensagemFinal = "Resetado";
}
    // Declara o estado de colisão no eixo horizontal.
    let colisaoX = false;
    // Declara o estado de colisão no eixo vertical.
    let colisaoY = false;

    // Percorre os itens ou repete as instruções do laço.
    for(const obs of obstaculos){

        // Verifica se a condição permite executar o bloco seguinte.
        if(
            colideRetanguloCirculo(
                novoX,
                // Atualiza a posição vertical do jogador.
                jogador.y,
                jogador.raio,
                obs.x,
                obs.y,
                obs.largura,
                obs.altura
            )
        ){
            // Atualiza o estado de colisão no eixo horizontal.
            colisaoX = true;
        }

        // Verifica se a condição permite executar o bloco seguinte.
        if(
            colideRetanguloCirculo(
                // Atualiza a posição horizontal do jogador.
                jogador.x,
                novoY,
                jogador.raio,
                obs.x,
                obs.y,
                obs.largura,
                obs.altura
            )
        ){
            // Atualiza o estado de colisão no eixo vertical.
            colisaoY = true;
        }
    }

    // Verifica se a condição permite executar o bloco seguinte.
    if(!colisaoX)
        // Atualiza a posição horizontal do jogador.
        jogador.x = novoX;

    // Verifica se a condição permite executar o bloco seguinte.
    if(!colisaoY)
        // Atualiza a posição vertical do jogador.
        jogador.y = novoY;

    // Limita o valor ao intervalo permitido.
    jogador.x = Math.max(
        jogador.raio,
        // Limita o valor ao intervalo permitido.
        Math.min(
            canvas.width-jogador.raio,
            // Atualiza a posição horizontal do jogador.
            jogador.x
        )
    );

    // Limita o valor ao intervalo permitido.
    jogador.y = Math.max(
        jogador.raio,
        // Limita o valor ao intervalo permitido.
        Math.min(
            canvas.height-jogador.raio,
            // Atualiza a posição vertical do jogador.
            jogador.y
        )
    );

    // Declara a diferença horizontal usada no cálculo.
    let dx = 0;
    // Declara a diferença vertical usada no cálculo.
    let dy = 0;

    // Verifica se a condição permite executar o bloco seguinte.
    if(teclas["ArrowUp"]) dy = -1;
    // Verifica se a condição permite executar o bloco seguinte.
    if(teclas["ArrowDown"]) dy = 1;
    // Verifica se a condição permite executar o bloco seguinte.
    if(teclas["ArrowLeft"]) dx = -1;
    // Verifica se a condição permite executar o bloco seguinte.
    if(teclas["ArrowRight"]) dx = 1;
    

    // Impede disparos durante a fase de compras.
    if(
        faseJogo === "jogando" &&
        // Compara os valores para determinar o resultado da condição.
        (dx !== 0 || dy !== 0) &&
        // Obtém o horário atual para controlar o tempo.
        Date.now() - jogador.ultimoDisparo >
        // Atualiza o intervalo mínimo entre disparos.
        jogador.cadencia
    ){

        // Declara o comprimento do vetor de direção.
        const tamanho =
            // Calcula o comprimento do vetor ou a distância entre pontos.
            Math.hypot(dx,dy);

        // Adiciona um novo item à lista.
        projeteis.push({

            // Define o valor da propriedade x.
            x:jogador.x,
            // Define o valor da propriedade y.
            y:jogador.y,

            // Define o valor da propriedade velX.
            velX:(dx/tamanho)*8,
            // Define o valor da propriedade velY.
            velY:(dy/tamanho)*8,

            // Define o raio do objeto circular.
            raio:4
        });

        // Atualiza o horário do último disparo.
        jogador.ultimoDisparo =
            // Obtém o horário atual para controlar o tempo.
            Date.now();
    }
}


// Atualiza os objetos e as regras da partida.
function atualizar(deltaTempo){

    // Verifica se a condição permite executar o bloco seguinte.
    if(jogoFinalizado) return;
    // Mantém o movimento disponível enquanto a loja está aberta.
    gerenciarControles();

    // Durante a loja, atualiza apenas o tempo na zona de início.
    if (faseJogo === "loja") {
        atualizarProgressoZona(deltaTempo);
        return;
    }

    // Percorre os itens ou repete as instruções do laço.
    for(let i=projeteis.length-1;i>=0;i--){

        // Declara o projétil processado neste ciclo.
        const p = projeteis[i];

        // Atualiza o valor de p.x.
        p.x += p.velX;
        // Atualiza o valor de p.y.
        p.y += p.velY;

        // Declara o estado que indica se o projétil será removido.
        let destruir = false;

        // Percorre os itens ou repete as instruções do laço.
        for(const obs of obstaculos){

            // Verifica se a condição permite executar o bloco seguinte.
            if(
                colideRetanguloCirculo(
                    p.x,
                    p.y,
                    p.raio,
                    obs.x,
                    obs.y,
                    obs.largura,
                    obs.altura
                )
            ){
                // Atualiza o estado que indica se o projétil será removido.
                destruir = true;
            }
        }

        // Verifica se a condição permite executar o bloco seguinte.
        if(
            destruir ||
            p.x<0 ||
            p.x>canvas.width ||
            p.y<0 ||
            p.y>canvas.height
        ){
            // Remove um item da lista.
            projeteis.splice(i,1);
        }
    }

    // Percorre os itens ou repete as instruções do laço.
    for(let i=inimigos.length-1;i>=0;i--){

        // Declara o inimigo processado neste ciclo.
        const e = inimigos[i];

        // Declara a diferença horizontal usada no cálculo.
        let dx = jogador.x - e.x;
        // Declara a diferença vertical usada no cálculo.
        let dy = jogador.y - e.y;

        // Declara a componente horizontal da direção do inimigo.
        let alvoX = dx;
        // Declara a componente vertical da direção do inimigo.
        let alvoY = dy;

        // Verifica se a condição permite executar o bloco seguinte.
        if(
            // Compara os valores para determinar o resultado da condição.
            e.tipo > .4 &&
            // Compara os valores para determinar o resultado da condição.
            e.tipo < .7 &&
            !e.chefe
        ){
            // Atualiza a componente horizontal da direção do inimigo.
            alvoX += dy*.5;
            // Atualiza a componente vertical da direção do inimigo.
            alvoY -= dx*.5;
        }

        // Verifica se a condição permite executar o bloco seguinte.
        if(
            e.tipo >= .7 &&
            !e.chefe
        ){

            // Verifica se a condição permite executar o bloco seguinte.
            if(
                // Obtém o horário atual para controlar o tempo.
                Date.now() >
                e.trocaDirecao
            ){

                // Atualiza o valor de e.direcaoX.
                e.direcaoX =
                    // Gera um valor aleatório para decidir esta ação.
                    (Math.random()-.5)*100;

                // Atualiza o valor de e.direcaoY.
                e.direcaoY =
                    // Gera um valor aleatório para decidir esta ação.
                    (Math.random()-.5)*100;

                // Atualiza o valor de e.trocaDirecao.
                e.trocaDirecao =
                    // Obtém o horário atual para controlar o tempo.
                    Date.now()+1000;
            }

            // Atualiza a componente horizontal da direção do inimigo.
            alvoX += e.direcaoX;
            // Atualiza a componente vertical da direção do inimigo.
            alvoY += e.direcaoY;
        }

        // Declara o comprimento do vetor de movimento.
        let norma =
            // Calcula o comprimento do vetor ou a distância entre pontos.
            Math.hypot(
                alvoX,
                alvoY
            );

        // Verifica se a condição permite executar o bloco seguinte.
        if(norma === 0)
            // Atualiza o comprimento do vetor de movimento.
            norma = 1;

        // Declara a próxima posição horizontal do inimigo.
        const proxX =
            e.x +
            (alvoX/norma)*
            e.velocidade;

        // Declara a próxima posição vertical do inimigo.
        const proxY =
            e.y +
            (alvoY/norma)*
            e.velocidade;

        // Declara a variável colisao usada pelo jogo.
        let colisao = false;

        // Declara o estado de colisão no eixo horizontal.
        let colisaoX = false;
        // Declara o estado de colisão no eixo vertical.
        let colisaoY = false;

        // Percorre os itens ou repete as instruções do laço.
        for(const obs of obstaculos){

            // Verifica se a condição permite executar o bloco seguinte.
            if(
                colideRetanguloCirculo(
                    proxX,
                    e.y,
                    e.raio,
                    obs.x,
                    obs.y,
                    obs.largura,
                    obs.altura
                )
            ){
                // Atualiza o estado de colisão no eixo horizontal.
                colisaoX = true;
            }

            // Verifica se a condição permite executar o bloco seguinte.
            if(
                colideRetanguloCirculo(
                    e.x,
                    proxY,
                    e.raio,
                    obs.x,
                    obs.y,
                    obs.largura,
                    obs.altura
                )
            ){
                // Atualiza o estado de colisão no eixo vertical.
                colisaoY = true;
            }
        }

        // Verifica se a condição permite executar o bloco seguinte.
        if(!colisaoX){
            // Atualiza o valor de e.x.
            e.x = proxX;
        }

        // Verifica se a condição permite executar o bloco seguinte.
        if(!colisaoY){
            // Atualiza o valor de e.y.
            e.y = proxY;
        }

        // Declara a distância entre o jogador e o inimigo.
        const distancia =
            // Calcula o comprimento do vetor ou a distância entre pontos.
            Math.hypot(
                // Atualiza a posição horizontal do jogador.
                jogador.x-e.x,
                // Atualiza a posição vertical do jogador.
                jogador.y-e.y
            );

        // Verifica se a condição permite executar o bloco seguinte.
        if(
            distancia <
            jogador.raio + e.raio
        ){

            // Atualiza a quantidade de vidas do jogador.
            jogador.vidas -=
                e.chefe ? 5 : 1;

            // Atualiza o texto mostrado na interface.
            txtVidas.innerText =
                // Atualiza a quantidade de vidas do jogador.
                jogador.vidas;

            // Remove um item da lista.
            inimigos.splice(i,1);

            // Verifica se a condição permite executar o bloco seguinte.
            if(jogador.vidas <= 0){

                // Atualiza o estado que bloqueia a partida após seu fim.
                jogoFinalizado = true;

                // Atualiza o texto exibido ao terminar a partida.
                mensagemFinal = "GAME OVER";
            }else{
                verificarOnda();
            }

            // Passa para a próxima repetição do laço.
            continue;
        }

        // Percorre os itens ou repete as instruções do laço.
        for(let j=projeteis.length-1;j>=0;j--){

            // Declara o projétil processado neste ciclo.
            const p = projeteis[j];

            // Declara a distância entre os objetos comparados.
            const d =
                // Calcula o comprimento do vetor ou a distância entre pontos.
                Math.hypot(
                    p.x-e.x,
                    p.y-e.y
                );

            // Verifica se a condição permite executar o bloco seguinte.
            if(
                d <
                p.raio + e.raio
            ){

                // Remove um item da lista.
                projeteis.splice(j,1);

                // Verifica se a condição permite executar o bloco seguinte.
                if(e.chefe){
                    e.vida--;

                    // Verifica se a condição permite executar o bloco seguinte.
                    if(e.vida <= 0){

                        // Atualiza a quantidade de inimigos eliminados.
                        jogador.abates++;
                        // Atualiza a quantidade de moedas do jogador.
                        jogador.moedas += 10;

                        // Atualiza o texto mostrado na interface.
                        txtMoedas.innerText =
                            // Atualiza a quantidade de moedas do jogador.
                            jogador.moedas;

                        // Remove um item da lista.
                        inimigos.splice(i,1);
                    }
                }else{

                    // Atualiza a quantidade de inimigos eliminados.
                    jogador.abates++;

                    // Verifica se a condição permite executar o bloco seguinte.
                    if(Math.random()<0.4){

                        // Adiciona um novo item à lista.
                        moedasMapa.push({

                            // Define o valor da propriedade x.
                            x:e.x,
                            // Define o valor da propriedade y.
                            y:e.y,
                            // Define o raio do objeto circular.
                            raio:6
                        });
                    }

                    // Remove um item da lista.
                    inimigos.splice(i,1);
                }

                // Atualiza o texto mostrado na interface.
                txtAbates.innerText =
                    // Atualiza a quantidade de inimigos eliminados.
                    jogador.abates;
                verificarOnda();

                // Encerra o laço atual.
                break;
            }
        }
    }

    // Percorre os itens ou repete as instruções do laço.
    for(let i=moedasMapa.length-1;i>=0;i--){

        // Declara a moeda processada neste ciclo.
        const m = moedasMapa[i];

        // Declara a distância entre os objetos comparados.
        const d =
            // Calcula o comprimento do vetor ou a distância entre pontos.
            Math.hypot(
                // Atualiza a posição horizontal do jogador.
                jogador.x-m.x,
                // Atualiza a posição vertical do jogador.
                jogador.y-m.y
            );

        // Verifica se a condição permite executar o bloco seguinte.
        if(
            d <
            jogador.raio+m.raio
        ){

            // Atualiza a quantidade de moedas do jogador.
            jogador.moedas++;

            // Atualiza o texto mostrado na interface.
            txtMoedas.innerText =
                // Atualiza a quantidade de moedas do jogador.
                jogador.moedas;

            // Remove um item da lista.
            moedasMapa.splice(i,1);
        }
    }

    // Abre a loja assim que a última moeda da onda for recolhida.
    verificarOnda();
}


// Desenha as plataformas e revela os detalhes apenas ao tocar no item.
function desenharLoja() {
    // Esconde a loja durante o combate.
    if (faseJogo !== "loja") return;

    ctx.textAlign = "center";
    ctx.font = "12px Arial";
    itensLoja.forEach((item, indice) => {
        const plataforma = item.plataforma;
        const centroX = plataforma.x + plataforma.largura / 2;

        // Desenha a plataforma correspondente a este item.
        ctx.fillStyle = "#5d4037";
        ctx.fillRect(
            plataforma.x,
            plataforma.y,
            plataforma.largura,
            plataforma.altura
        );
        ctx.strokeStyle = ["#ef5350", "#42a5f5", "#ffee58"][indice];
        ctx.lineWidth = 3;
        ctx.strokeRect(
            plataforma.x,
            plataforma.y,
            plataforma.largura,
            plataforma.altura
        );

        // Mantém o ícone visível mesmo quando os detalhes estão ocultos.
        ctx.fillStyle = "white";
        ctx.font = "30px Arial";
        ctx.fillText(item.icone, centroX, plataforma.y - 8);

        // Mostra nome, preço e instrução somente ao tocar no ícone.
        if (jogadorTocandoItem(indice)) {
            ctx.font = "12px Arial";
            ctx.fillText(item.nome, centroX, plataforma.y + 22);
            ctx.fillText(`${item.preco} moedas`, centroX, plataforma.y + 43);
            ctx.fillText("Aperte E para comprar", centroX, plataforma.y + 64);
        }
    });

    // Desenha a zona onde o jogador inicia a próxima onda.
    ctx.beginPath();
    ctx.arc(
        zonaIniciarOnda.x,
        zonaIniciarOnda.y,
        zonaIniciarOnda.raio,
        0,
        Math.PI * 2
    );
    ctx.fillStyle = "rgba(255, 213, 79, 0.2)";
    ctx.fill();
    ctx.strokeStyle = "#ffd54f";
    ctx.lineWidth = 3;
    ctx.stroke();

    ctx.fillStyle = "white";
    ctx.font = "14px Arial";
    ctx.fillText(
        `Fique aqui ${tempoParaIniciarOnda} s para iniciar`,
        zonaIniciarOnda.x,
        zonaIniciarOnda.y - zonaIniciarOnda.raio - 10
    );

    // Exibe o tempo acumulado na zona como uma barra de progresso.
    const larguraBarra = 90;
    ctx.fillStyle = "#333";
    ctx.fillRect(
        zonaIniciarOnda.x - larguraBarra / 2,
        zonaIniciarOnda.y + zonaIniciarOnda.raio + 5,
        larguraBarra,
        8
    );
    ctx.fillStyle = "#76ff03";
    ctx.fillRect(
        zonaIniciarOnda.x - larguraBarra / 2,
        zonaIniciarOnda.y + zonaIniciarOnda.raio + 5,
        larguraBarra * Math.min(progressoZona / tempoParaIniciarOnda, 1),
        8
    );

    // Exibe o resultado da compra ou uma mensagem de orientação.
    if (mensagemLoja) {
        ctx.fillStyle = "white";
        ctx.font = "16px Arial";
        ctx.fillText(mensagemLoja, canvas.width / 2, canvas.height - 12);
    }
}

function desenhar(){

    // Limpa o quadro anterior do canvas.
    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    // Percorre os itens ou repete as instruções do laço.
    obstaculos.forEach(obs=>{

        // Define a aparência do desenho no canvas.
        ctx.fillStyle="#6d4c41";

        // Desenha um retângulo no canvas.
        ctx.fillRect(
            obs.x,
            obs.y,
            obs.largura,
            obs.altura
        );
    });

    // Exibe a loja apenas durante o intervalo entre ondas.
    desenharLoja();

    // Inicia um novo desenho no canvas.
    ctx.beginPath();
    // Define um círculo para desenhar.
    ctx.arc(
        // Atualiza a posição horizontal do jogador.
        jogador.x,
        // Atualiza a posição vertical do jogador.
        jogador.y,
        jogador.raio,
        0,
        Math.PI*2
    );
    // Define a aparência do desenho no canvas.
    ctx.fillStyle="#1976d2";
    // Define a aparência do desenho no canvas.
    ctx.fill();

    // Percorre os itens ou repete as instruções do laço.
    projeteis.forEach(p=>{

        // Inicia um novo desenho no canvas.
        ctx.beginPath();

        // Define um círculo para desenhar.
        ctx.arc(
            p.x,p.y,
            p.raio,
            0,
            Math.PI*2
        );

        // Define a aparência do desenho no canvas.
        ctx.fillStyle="gold";
        // Define a aparência do desenho no canvas.
        ctx.fill();
    });

    // Percorre os itens ou repete as instruções do laço.
    moedasMapa.forEach(m=>{

        // Inicia um novo desenho no canvas.
        ctx.beginPath();

        // Define um círculo para desenhar.
        ctx.arc(
            m.x,m.y,
            m.raio,
            0,
            Math.PI*2
        );

        // Define a aparência do desenho no canvas.
        ctx.fillStyle="yellow";
        // Define a aparência do desenho no canvas.
        ctx.fill();
    });

    // Percorre os itens ou repete as instruções do laço.
    inimigos.forEach(e=>{

        // Inicia um novo desenho no canvas.
        ctx.beginPath();

        // Define um círculo para desenhar.
        ctx.arc(
            e.x,
            e.y,
            e.raio,
            0,
            Math.PI*2
        );

        // Define a aparência do desenho no canvas.
        ctx.fillStyle =
            e.chefe
            // Escolhe o valor correspondente ao resultado da condição.
            ? "#c62828"
            // Escolhe o valor correspondente ao resultado da condição.
            : "#8e24aa";

        // Define a aparência do desenho no canvas.
        ctx.fill();

        // Verifica se a condição permite executar o bloco seguinte.
        if(e.chefe){

            // Define a aparência do desenho no canvas.
            ctx.fillStyle="white";
            // Define a aparência do desenho no canvas.
            ctx.font="12px Arial";

            // Desenha o texto indicado no canvas.
            ctx.fillText(
                e.vida,
                e.x-8,
                e.y+4
            );
        }
    });

    // Verifica se a condição permite executar o bloco seguinte.
    if(jogoFinalizado){

        // Atualiza a aparência do elemento na página.
        btnRestart.style.display =
            "inline-block";

        // Define a aparência do desenho no canvas.
        ctx.fillStyle =
            "rgba(0,0,0,0.8)";

        // Desenha um retângulo no canvas.
        ctx.fillRect(
            0,
            0,
            canvas.width,
            canvas.height
        );

        // Define a aparência do desenho no canvas.
        ctx.fillStyle =
            venceu
            // Escolhe o valor correspondente ao resultado da condição.
            ? "#00ff66"
            // Escolhe o valor correspondente ao resultado da condição.
            : "#ff4444";

        // Define a aparência do desenho no canvas.
        ctx.font =
            "60px Arial";

        // Define a aparência do desenho no canvas.
        ctx.textAlign =
            "center";

        // Desenha o texto indicado no canvas.
        ctx.fillText(
            mensagemFinal,
            canvas.width/2,
            canvas.height/2 - 40
        );

        // Define a aparência do desenho no canvas.
        ctx.fillStyle =
            "white";

        // Define a aparência do desenho no canvas.
        ctx.font =
            "24px Arial";

        // Desenha o texto indicado no canvas.
        ctx.fillText(
            "Abates: " +
            // Atualiza a quantidade de inimigos eliminados.
            jogador.abates,
            canvas.width/2,
            canvas.height/2 + 20
        );

        // Desenha o texto indicado no canvas.
        ctx.fillText(
            "Moedas: " +
            // Atualiza a quantidade de moedas do jogador.
            jogador.moedas,
            canvas.width/2,
            canvas.height/2 + 60
        );
    }
}



// Executa e agenda o próximo ciclo do jogo.
let ultimoFrame = performance.now();

function gameLoop(timestamp) {
    // Calcula o tempo do quadro para a contagem não depender do FPS.
    const deltaTempo = Math.min((timestamp - ultimoFrame) / 1000, 0.05);
    ultimoFrame = timestamp;

    // Verifica se a condição permite executar o bloco seguinte.
    if (jogoIniciado) {
        // Verifica se a condição permite executar o bloco seguinte.
        if (!jogoPausado) {
            atualizar(deltaTempo);
        }
        desenhar();
    }

    // Agenda o próximo quadro da animação.
    requestAnimationFrame(gameLoop);
}
gameLoop(performance.now());
